import React, { Component } from "react";
const styles = {
  h1: {
    color: "#b22222",
    textAlign: "center",
  },
  h2: {
    color: "#b22222",
  },
  p: {
    fontSize: "large",
    color: "#dc143c",
  },
  div: {
    backgroundColor: "#ffe4c4",
    borderStyle: "dotted",
    color: "#4c684c",
  },
};
var data = [
  {
    bikename: "Benling Aura",
    cost: "$500",
    batteryChargeTime: "3.5 hours",
    speed: "15 mph",
  },
  {
    bikename: "Okiawa i-Praise",
    cost: "$1000",
    batteryChargeTime: "5 hours",
    speed: "20 mph",
  },
  {
    bikename: "Hero Electric Nyx",
    cost: "$1500",
    batteryChargeTime: "7 hours",
    speed: "25 mph",
  },
  {
    bikename: "Revolt RV ",
    cost: "$1800",
    batteryChargeTime: "8 hours",
    speed: "30 mph",
  },
];

class Info extends Component {
  // IMPLEMENT YOUR CODE HERE
  //Add styles to respective tags
  render() {
    return (
        <div style={styles.div}>
            <h1 style={styles.h1}>Its Great to see you in future!!!</h1>
            <h2 style={styles.h2}>Please find the details below</h2>
            {data.map((bike) => (
                <dl key={bike.bikename}>
                    <dt>{bike.bikename}</dt>
                    <dd>{bike.cost}</dd>
                    <dd>{bike.batteryChargeTime}</dd>
                    <dd>{bike.speed}</dd>
                </dl>
            ))};
            <p style={styles.p}>**All payment related information and other important updates will be shared on those contact details only.</p>
            <p style={styles.p}>**The price of motorcycle shall be applicable as prevailing on the date of delivery of motorcycle to customer.</p>
        </div>
    );
  }
}
export default Info;
