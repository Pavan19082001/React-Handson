import React, { Component } from "react";
const styles = {
  table: {
    backgroundColor: "#8fbc8f",
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: "50px",
  },
  h1: {
    textAlign: "center",
    color: "#b22222",
  },
  form: {
    backgroundColor: "#ffe4c4",
    borderStyle: "dotted",
  },
};
class BookABike extends Component {
  //IMPLEMENT YOUR CODE HERE.
  constructor(props){
    super(props);
    this.state={
        name: '',
        email: '',
        mobile: '',
        Lid: '',
        Ldate: '',
        brand: '',
        colour: '',
        message: ''
    }
  };

  handleSubmit = (e) =>{
    e.preventDefault();

    const {name, email, mobile, Lid, Ldate, colour, brand} = this.state;

    if(name == "" || email == "" || mobile == "" || Lid == "" || Ldate == "" || colour == "" || brand == ""){
        this.setState({message: `Please fill all the required fields`});
        return;
    }

    if(Lid.length < 9 || Lid.length > 13){
        this.setState({message: 'Check your License Number and register again'});
        return;
    }

    const currDate = new Date();
    const selectedDate = new Date(Ldate);

    if(selectedDate > currDate){
        const deliveryDate = new Date();
        deliveryDate.setDate(currDate.getDate() + 20);
        this.setState({message: `Hai ${name}. Your Registration for ${brand} is successful. Tentative Delivery Date will be on 
        ${deliveryDate.getDate()}-${deliveryDate.getMonth()+1}-${deliveryDate.getFullYear()}`});
    }else{
        this.setState({message: `Hai ${name} !!! Check your License Validity and register again`});
    }

  };

  render() {
    const {name, email, mobile, Lid, Ldate, brand, colour, message} = this.state;
    return (
        <div>
            <form style={styles.form} onSubmit={this.handleSubmit}>
                <h1 style={styles.h1}>Bon Voyage!!</h1>

                <table style={styles.table}>
                    <tbody>
                        <tr>
                            <td><label>Name:</label></td>
                            <td><input type="text" id="name" placeholder="Enter your Name" name="name" value={name}
                             onChange={(e)=>this.setState({name: e.target.value})} /></td>
                        </tr>

                        <tr>
                            <td><label>Email Id:</label></td>
                            <td><input type="email" id="email" placeholder="Enter your Email" name="email" value={email} 
                            onChange={(e)=>this.setState({email: e.target.value})} /></td>
                        </tr>

                        <tr>
                            <td><label>Mobile Number:</label></td>
                            <td><input type="tel" id="mobile" placeholder="Enter your mobile number" name="mobile" value={mobile} 
                            onChange={(e)=>this.setState({mobile: e.target.value})} /></td>
                        </tr>

                        <tr>
                            <td><label>License Id:</label></td>
                            <td><input type="text" id="Lid" placeholder="Enter your License ID" name="Lid" value={Lid}
                             onChange={(e)=>this.setState({Lid: e.target.value})} /></td>
                        </tr>

                        <tr>
                            <td><label>License Expiry Date:</label></td>
                            <td><input type="date" id="Ldate" name="Ldate" value={Ldate}
                             onChange={(e)=>this.setState({Ldate: e.target.value})} /></td>
                        </tr>

                        <tr>
                            <td><label>Brand Selection:</label></td>
                            <td><select id="brand" name="brand" value={brand} onChange={(e)=>this.setState({brand: e.target.value})} >
                                <option value=''>Select Brand</option>
                                <option value='Benling'>Benling Aura</option>
                                <option value='ipraise'>Okiawa i-praise</option>
                                <option value='Hero'>Hero Electric Nyx</option>
                                <option value='Revolt'>Revolt RV</option>
                            </select></td>
                        </tr>

                        <tr>
                            <td><label>Choose colour:</label></td>
                            <td>
                                <select id="colour" name="colour" value={colour} 
                                onChange={(e)=>this.setState({colour: e.target.value})} >
                                    <option value="">Select the colour</option>
                                    <option value="Red">Rebel Red</option>
                                    <option value="Grey">Mist Grey</option>
                                    <option value="Black">Cosmic Black</option>
                                </select>
                            </td>
                        </tr>
                    </tbody>
                </table>

            <button type="submit" id="submit" name="Submit" 
            style={{textAlign: 'center', marginTop: 'auto', paddingTop: '75px'}}>Submit</button>

            <div style={{color: '#dc143c', textAlign: 'center', marginTop: '20px'}}>{message}</div>
            </form>
        </div>
    );
  }
}

export default BookABike;
