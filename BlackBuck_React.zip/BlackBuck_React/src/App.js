import React, { Component } from "react";
import { BrowserRouter as Router, Route, Link, Routes } from "react-router-dom";
import BookABike from "./Components/BookABike";
import Info from "./Components/Info";

const styles = {
  //IMPLEMENT STYLE HERE.
  h1: {
    color: '#fff8dc',
    fontWeight: 'bold',
    backgroundColor: '#8fbc8f',
    fontStyle: 'oblique',
    textAlign: 'center'
  },

  h2: {
    color: '#228b22',
    fontWeight: 'bold',
    fontStyle: 'oblique'
  }
};
class App extends Component {
  //IMPLEMENT YOUR CODE HERE
  render() {
    return (
        <div>
            <h1 style={styles.h1}>BlackBuck Dealer</h1>
            <h2 style={styles.h2}>Online Electric Bike Booking</h2>
            <ul>
                <li><Link to="/Info">Info</Link></li>
                <li><Link to="/bookabike">Book A Bike</Link></li>
            </ul>
            <Routes>
                <Route exact path="/Info" Component={Info} />
                <Route exact path="/bookabike" Component={BookABike} />
            </Routes>
        </div>
    );
  }
}
export default App;
